﻿CREATE TABLE [dbo].[SdlTbl] (
    [EId]       INT           IDENTITY (1, 1) NOT NULL,
    [EDesc]     VARCHAR (50)  NOT NULL,
    [EDate]     DATETIME2 (7) NOT NULL,
    [EDuration] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([EId] ASC)
);

