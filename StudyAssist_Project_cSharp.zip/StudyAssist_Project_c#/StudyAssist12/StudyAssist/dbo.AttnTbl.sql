﻿CREATE TABLE [dbo].[AttnTbl] (
    [AttnNum]   INT           IDENTITY (1, 1) NOT NULL,
    [AttTid]    NVARCHAR (50) NOT NULL,
    [AttTName]  VARCHAR (50)  NOT NULL,
    [AttDate]   DATE          NOT NULL,
    [AttStatus] VARCHAR (50)  NOT NULL,
    PRIMARY KEY CLUSTERED ([AttnNum] ASC)
);

