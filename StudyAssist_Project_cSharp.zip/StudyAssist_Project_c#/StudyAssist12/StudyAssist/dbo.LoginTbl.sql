﻿CREATE TABLE [dbo].[LoginTbl] (
    [UserNm]  VARCHAR (50)  NOT NULL,
    [Passwrd] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([UserNm] ASC)
);

