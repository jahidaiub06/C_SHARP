﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyAssist
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void UserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        

        private void Log_Click(object sender, EventArgs e)
        {

            SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-7NV4G7M\SQLEXPRESS;Initial Catalog=StudyAssist;User ID=sa;Password=12345");

            string query = "Select * from LoginTbl where Usernm='" + textBox1.Text.Trim() + "' and Passwrd = '" + textBox2.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);

            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                if (dtbl.Rows.Count == 1)
                {
                    MainMenu f1 = new MainMenu();
                    this.Hide();
                    f1.Show();
                }

                else
                {
                    MessageBox.Show("Wrong username or Wrong password");
                }
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void TextBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                e.Cancel = true;
                textBox1.Focus();
                errorProvider1.SetError(textBox1, "Please Enter your User Name !");
            }
            else
            {
                errorProvider1.SetError(textBox1, null);
            }
        }

        private void TextBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                e.Cancel = true;
                textBox2.Focus();
                errorProvider2.SetError(textBox2, "Please Enter your Pass word !");
            }
            else
            {
                errorProvider2.SetError(textBox2, null);
            }
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            Select Obj = new Select();
            this.Hide();
            Obj.Show();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}

