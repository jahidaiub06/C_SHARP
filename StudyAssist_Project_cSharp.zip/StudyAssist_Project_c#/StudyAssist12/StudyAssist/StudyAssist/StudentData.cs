﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyAssist
{
    public partial class StudentData : Form
    {
        public StudentData()
        {
            InitializeComponent();
            DisplayStudentData();
        }
        SqlConnection Con =  new SqlConnection(@"Data Source=DESKTOP-7NV4G7M\SQLEXPRESS;Initial Catalog=StudyAssist;User ID=sa;Password=12345");

        private void DisplayStudentData()
        {
            Con.Open();
            string Query = "Select * from RegisterTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder bldr = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            StDgv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void StDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            MainMenu Obj = new MainMenu();
            Obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from RegisterTbl where UserName like'" + this.search.Text + "%'", Con);

            da.Fill(dt);
            StDgv.DataSource = dt;
            Con.Close();
        }
    }
}
