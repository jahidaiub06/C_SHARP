﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyAssist
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                e.Cancel = true;
                textBox1.Focus();
                errorProvider1.SetError(textBox1, "Please Enter your first Name !");
            }
            else
            {
                errorProvider1.SetError(textBox1, null);
            }
        }


        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                e.Cancel = true;
                textBox3.Focus();
                errorProvider3.SetError(textBox3, "Please Enter your Phone Number !");
            }
            else
            {
                errorProvider3.SetError(textBox3, null);
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                e.Cancel = true;
                textBox4.Focus();
                errorProvider4.SetError(textBox4, "Please Enter your Phone Number !");
            }
            else
            {
                System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
+ @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
+ @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$");
                if (textBox4.Text.Length > 0)
                {
                    if (!rEmail.IsMatch(textBox4.Text))
                    {
                        MessageBox.Show("Invalid Email pattern");
                    }
                }
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))
            {
                e.Cancel = true;
                textBox5.Focus();
                errorProvider5.SetError(textBox5, "Please Enter your Phone Number !");
            }
            else
            {
                errorProvider5.SetError(textBox5, null);
            }
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-7NV4G7M\SQLEXPRESS;Initial Catalog=StudyAssist;User ID=sa;Password=12345");

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || comboBox1.SelectedIndex == -1 || textBox3.Text == "" || textBox4.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into RegisterTbl(UserName,Gender,PhoneNumber,EMail,Address)values (@Sname,@SGen,@SNum,@SMail,@SAdd)", Con);
                    cmd.Parameters.AddWithValue("@Sname", textBox1.Text);
                    cmd.Parameters.AddWithValue("@SGen", comboBox1.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@SNum", textBox3.Text);
                    cmd.Parameters.AddWithValue("@SMail", textBox4.Text);
                    cmd.Parameters.AddWithValue("@SAdd", textBox5.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registration Succesful");
                    Con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StLogin Obj = new StLogin();
            this.Hide();
            Obj.Show();
        }

        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.SelectedItem.ToString()))
            {
                e.Cancel = true;
                comboBox1.Focus();
                errorProvider2.SetError(comboBox1, "Please Enter your last name !");
            }
            else
            {
                errorProvider2.SetError(comboBox1, null);
            }
        }
    }
}
