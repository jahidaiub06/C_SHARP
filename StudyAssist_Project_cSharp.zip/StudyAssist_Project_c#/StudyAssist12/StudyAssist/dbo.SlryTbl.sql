﻿CREATE TABLE [dbo].[SlryTbl] (
    [PayId]   INT          IDENTITY (1, 1) NOT NULL,
    [MgrId]   INT          NOT NULL,
    [MgrName] VARCHAR (50) NOT NULL,
    [Month]   VARCHAR (50) NOT NULL,
    [Amt]     INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([PayId] ASC)
);

