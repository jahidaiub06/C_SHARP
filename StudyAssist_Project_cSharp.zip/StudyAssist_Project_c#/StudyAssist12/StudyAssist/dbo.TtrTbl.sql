﻿CREATE TABLE [dbo].[TtrTbl] (
    [TId]    INT           IDENTITY (1, 1) NOT NULL,
    [Tname]  VARCHAR (50)  NOT NULL,
    [TGen]   VARCHAR (10)  NOT NULL,
    [TDob]   VARCHAR (50)  NOT NULL,
    [TSub]   VARCHAR (50)  NOT NULL,
    [TSal]   VARCHAR (50)  NOT NULL,
    [TPhone] VARCHAR (50)  NOT NULL,
    [TAdd]   VARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([TId] ASC)
);

