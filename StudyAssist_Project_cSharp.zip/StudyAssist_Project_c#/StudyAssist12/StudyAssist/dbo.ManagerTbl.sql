﻿CREATE TABLE [dbo].[ManagerTbl] (
    [MgrId]     INT          IDENTITY (1, 1) NOT NULL,
    [MgrName]   VARCHAR (50) NOT NULL,
    [MgrGen]    VARCHAR (10) NOT NULL,
    [MgrDob]    DATE         NOT NULL,
    [MgrBranch] VARCHAR (20) NOT NULL,
    [MgrSalary] INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([MgrId] ASC)
);

