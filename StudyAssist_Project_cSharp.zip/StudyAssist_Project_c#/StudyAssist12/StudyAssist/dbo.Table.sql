﻿CREATE TABLE [dbo].[RegisterTbl]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [UserName] VARCHAR(50) NOT NULL, 
    [Gender] VARCHAR(50) NOT NULL, 
    [PhoneNumber] INT NOT NULL, 
    [EMail] NVARCHAR(50) NOT NULL, 
    [Address] VARCHAR(MAX) NOT NULL
)
